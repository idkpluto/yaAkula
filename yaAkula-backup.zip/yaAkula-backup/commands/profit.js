const used = new Map();
const Duration = require('humanize-duration');
   


module.exports.run = async (bot, message, args) => {


  
}

module.exports.help = {
    name: "test",
    aliases: []
}